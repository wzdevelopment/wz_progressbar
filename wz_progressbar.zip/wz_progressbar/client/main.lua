ESX = nil

Citizen.CreateThread(function()
    while ESX == nil do
        Citizen.Wait(100)

        ESX = exports["es_extended"]:getSharedObject()
    end

    if ESX.IsPlayerLoaded() then
        ESX.PlayerData = ESX.GetPlayerData()
    end
end)

RegisterNetEvent("esx:playerLoaded")
AddEventHandler("esx:playerLoaded", function(response)
    ESX.PlayerData = response
end)

RegisterNetEvent("wz_progressbar:startDelayedFunction")
AddEventHandler("wz_progressbar:startDelayedFunction", function(data)
    StartDelayedFunction(data)
end)