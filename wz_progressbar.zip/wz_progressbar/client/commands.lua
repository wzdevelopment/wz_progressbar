RegisterCommand("delayedfunction", function()
    local testData = {
        ["text"] = "Bandage",
        ["delay"] = 9000
    }

    StartDelayedFunction(testData)
end)